# Hiro Itawn (fbft.fr) World Save - Snapshot Details
![Server Icon](../icon.png)

- **Time**: `Sat, 25 May 2024 16:03:18 +0200` (Timestamp: `1716645798278`)
- **Captured By**: `SuperJeannot`

## Server
- **List Entry Name**: `Fbft`
- **IP**: `fbft.fr`
- **Capacity**: `1/20`
- **Brand**: `Paper`
- **MOTD**: `A Minecraft Server`
- **Version**: `Paper 1.20.4`
- **Protocol Version**: `765`
- **Server Type**: `OTHER`
- **Short Label**: `AutoCrystalBot`
- **Full Label**: `AutoCrystalBot`

## Connection
- **Host Name**: `ns3271018.ip-5-39-85.eu`
- **Port**: `25565`
- **Session ID**: `553ebe88-601b-4bce-a33a-ce9706bf42fa`

This file was created by [WorldTools 1.2.4](https://github.com/Avanatiker/WorldTools/)
