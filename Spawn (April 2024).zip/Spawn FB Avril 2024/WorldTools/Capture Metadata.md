# Spawn FB Avril 2024 (fbft.fr) World Save - Snapshot Details
![Server Icon](../icon.png)

- **Time**: `Sun, 21 Apr 2024 20:48:06 +0200` (Timestamp: `1713725286103`)
- **Captured By**: `SuperJeannot`

## Server
- **List Entry Name**: `Fbft`
- **IP**: `fbft.fr`
- **Capacity**: `3/20`
- **Brand**: `Paper`
- **MOTD**: `A Minecraft Server`
- **Version**: `Paper 1.20.4`
- **Protocol Version**: `765`
- **Server Type**: `OTHER`
- **Short Label**: `chatei, GraniticStone, SomeBoringNerd`
- **Full Label**: `chatei GraniticStone SomeBoringNerd`

## Connection
- **Host Name**: `ns3271018.ip-5-39-85.eu`
- **Port**: `25565`
- **Session ID**: `8c6dd233-dd8d-473e-aa4b-c2cae63b4a2d`

This file was created by [WorldTools 1.2.4](https://github.com/Avanatiker/WorldTools/)
