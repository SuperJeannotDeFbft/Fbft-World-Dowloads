# eurynone end base (fbft.fr) World Save - Snapshot Details
![Server Icon](../icon.png)

- **Time**: `Wed, 24 Apr 2024 21:43:12 +0200` (Timestamp: `1713987792726`)
- **Captured By**: `SuperJeannot`

## Server
- **List Entry Name**: `Fbft`
- **IP**: `fbft.fr`
- **Capacity**: `1/20`
- **Brand**: `Paper`
- **MOTD**: `A Minecraft Server`
- **Version**: `Paper 1.20.4`
- **Protocol Version**: `765`
- **Server Type**: `OTHER`
- **Short Label**: `Kalyax, SuperJeannot`
- **Full Label**: `Kalyax SuperJeannot`

## Connection
- **Host Name**: `ns3271018.ip-5-39-85.eu`
- **Port**: `25565`
- **Session ID**: `25c7fa14-ae6d-4403-9694-d32e0099f2b9`

This file was created by [WorldTools 1.2.4](https://github.com/Avanatiker/WorldTools/)
