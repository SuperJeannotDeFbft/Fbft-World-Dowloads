# Spawn Tempmap (May 26th 2025) (fbft.fr) World Save - Snapshot Details
![Server Icon](../icon.png)

- **Time**: `Mon, 26 May 2025 10:46:19 +0200` (Timestamp: `1748249179426`)
- **Captured By**: `Lord_Tangp`

## Server
- **List Entry Name**: `Fbft`
- **IP**: `fbft.fr`
- **Capacity**: `1/15`
- **Brand**: `FBFT`
- **MOTD**: `FB BACK ON THE ORIGINAL MAP ! FT`
- **Version**: `FBFT 1.21.4`
- **Protocol Version**: `769`
- **Server Type**: `OTHER`
- **Short Label**: `Anonymous Player`
- **Full Label**: `Anonymous Player`

## Connection
- **Host Name**: `194.213.3.3`
- **Port**: `25565`
- **Session ID**: `dec5fd04-c8bc-4add-b99c-263882ab152e`

This file was created by [WorldTools 1.2.8](https://github.com/Avanatiker/WorldTools/)
