# fbft.fr_25565 World Save - Snapshot Details
![Server Icon](../icon.png)

- **Time**: `Thu, 19 Jun 2025 18:08:56 +0200` (Timestamp: `1750349336876`)
- **Captured By**: `requindeshanghai`

## Server
- **List Entry Name**: `FBFT`
- **IP**: `fbft.fr:25565`
- **Capacity**: `5/30`
- **Brand**: `FBFT`
- **MOTD**: `FB BACK ON THE ORIGINAL MAP ! FT`
- **Version**: `FBFT 1.21.4`
- **Protocol Version**: `769`
- **Server Type**: `OTHER`
- **Short Label**: `_SeynoX_, Anonymous Player, discord_gg_feur, Anonymous Player, mashfermash`
- **Full Label**: `_SeynoX_ Anonymous Player discord_gg_feur Anonymous Player mashfermash`

## Connection
- **Host Name**: `ns3148850.ip-51-91-13.eu`
- **Port**: `25565`
- **Session ID**: `3be95585-39b3-4c86-b657-aeacc275d3d8`

This file was created by [WorldTools 1.2.8](https://github.com/Avanatiker/WorldTools/)
