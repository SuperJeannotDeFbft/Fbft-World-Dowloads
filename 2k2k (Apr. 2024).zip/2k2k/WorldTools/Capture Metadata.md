# 2k2k (fbft.fr) World Save - Snapshot Details
![Server Icon](../icon.png)

- **Time**: `Thu, 25 Apr 2024 14:11:04 +0200` (Timestamp: `1714047064074`)
- **Captured By**: `SuperJeannot`

## Server
- **List Entry Name**: `Fbft`
- **IP**: `fbft.fr`
- **Capacity**: `0/20`
- **Brand**: `Paper`
- **MOTD**: `A Minecraft Server`
- **Version**: `Paper 1.20.4`
- **Protocol Version**: `765`
- **Server Type**: `OTHER`

## Connection
- **Host Name**: `ns3271018.ip-5-39-85.eu`
- **Port**: `25565`
- **Session ID**: `89926994-690e-4e80-9c82-2448dc1a9d94`

This file was created by [WorldTools 1.2.4](https://github.com/Avanatiker/WorldTools/)
